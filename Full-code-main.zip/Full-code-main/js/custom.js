(function($) {
	
	$.fn.equalHeights = function(){
		return this.height( Math.max.apply(this, $.map( this , function(e){ return $(e).height() }) ) );
	};
	$.fn.equalWidths = function(){
		return this.width( Math.max.apply(this, $.map( this , function(e){ return $(e).width() }) ) );
	};
	lastMenuStatus = false;
	
	$(function(){
		
		$("#menubutton a").click(function(e) {
			e.preventDefault();
			
			
			$("#menu-area").toggle();
			//$("#menu-area #menu > ul > li").removeClass("active");
			
			if($("#menu-area").is(":visible")) {
				$("#menu-area").addClass("visible");
				$("body").addClass("noscroll");
				lastMenuStatus = true;
			}
			else {
				$("#menu-area").removeClass("visible");
				$("body").removeClass("noscroll");
				lastMenuStatus = false;
			}
			
		});
		
		
		$("#menu").find("ul > li.dropdown > a").click(function(e) {
			e.preventDefault();
			//$(this).parent().toggleClass("active");
			
		});
		$("#menu").hover(function () {
		
		});
		$(document).click(function(e) {
			if (e.target.id != 'menu'
				&& e.target.id != 'menubutton'
				&& !$('#menu-area').find(e.target).length
				&& !$('#menubutton').find(e.target).length
				&& $("#menubutton").is(":visible"))
			{
				$("#menu-area").hide();
				$("#menu-area").removeClass("visible");
				$("body").removeClass("noscroll");
				lastMenuStatus = false;
			}
			
			
		});
		
		$("a[href='#']").click(function (e) {
			e.preventDefault();
		});
		
		
		
		$(".worldmap .pins a").click(function (e) {
			e.preventDefault();
			var href = $(this).attr("href");
			
			$(".worldmap .databox").hide();
			$(".worldmap .databox"+href).delay(100).fadeIn("slow");
			
			var span = $(this).find("span");
			
			
			var scale = 1;
			
			if($(".worldmap").css('transform') !== "none") {
				
    			var matches = $(".worldmap").css('transform').match(
    				/matrix\((-?\d*\.?\d+),\s*0,\s*0,\s*(-?\d*\.?\d+),\s*(-?\d*\.?\d+),\s*0\)/
				);
				scale = matches[1];
				
			}
			
			
			$(".worldmap-shadow")
				.stop(true,true)
				.css("left",span.offset().left)
				.css("top",span.offset().top)
				.css("width",$(this).width()*scale)
				.css("height",$(this).height()*scale)
				.show();
			
			
			var databoxes = $(".worldmap .databoxes");
			$(".worldmap-shadow").animate({
				"left": databoxes.offset().left,
				"top": databoxes.offset().top,
				"width": databoxes.width(),
				"height": databoxes.height(),
			}, 300, function() {
				$(this).fadeOut("fast");
			});
			
		});
		
		$(".selector-links a").click(function (e) {
			e.preventDefault();
			var target = $(this).data("target");
			
			$(".selector-links a").removeClass("selected");
			$(this).addClass("selected");
			
			$(".package").hide();
			$(".package-" + target).show();
		});
		$(".selector-links a").eq(0).addClass("selected");
		
		$( "select#select-location" ).change(function() {
			var target = $( "select#select-location" ).val();
			$(".select-packages").hide();
			$(".select-packages."+ target).css("display","flex");
		});
		$(".more-specs").each(function(i,e) {
			var contents = e.innerHTML.trim();
			e.innerHTML = "";
			var newHTML = "<ul>";
			arrayOfLines = contents.match(/[^\r\n]+/g);
			
			for(var l=0; l< arrayOfLines.length; l++) {
				var line;
				if((line = arrayOfLines[l].trim()) !== "") {
					
					newHTML += "<li>" + line + "</li>";
				}
			}
			newHTML += "</ul>";
			e.innerHTML = newHTML;
		});
		
		$(".compact-features .linkers a").each(function(i,e) {
			$(e).data("assoc",i);
		});
		$(".compact-features .linkers a").click(function (e) {
			e.preventDefault();
			$(".compact-features .linkers a").removeClass("selected");
			$(this).addClass("selected");
			var assoc = $(this).data("assoc");
			$(".compact-features .content").hide().eq(assoc).show();
		});
		
		$("copy").each(function(i,e) {
			var copyfrom = $(e).data("from");
			var newElements = $("#" + copyfrom + "").html()
			var newNode = $(newElements);
			newNode.find(".order").remove();
			console.log(newNode);
			$(e).replaceWith(newNode);
		});
		
		if($(".worldmap .databoxes").length) {
			
			var shadow = $("<div>").addClass("worldmap-shadow").appendTo($("body"));
			
			var elm = $("<div>").addClass("arrows").append("<a id='worldmap-arrow-left'></a><a id='worldmap-arrow-right'></a>").appendTo($(".worldmap .databoxes"));
			
			
			
			elm.find("a").click(function (e) {
				e.preventDefault();
				var id = $(this).attr("id") === "worldmap-arrow-left" ? "left" : "right";
				
				var databoxes = $(".worldmap .databox");
				var count = databoxes.length;
				var index = 0;
				for(var i = 0; i < count; i++) {
					if(databoxes.eq(i).is(":visible"))
						index = i;
				}
				databoxes.hide().eq((index+count+(id === "left" ? -1 : 1)) % count).fadeIn("fast");
				
				
			});
		}
		
		$(".game-intro .game-text i").after("<sub>");
		
		if($(".game-order-details").eq(1).length)
			$(".game-order-details").eq(1).html(
				$(".game-order-details").eq(0).html()
			)
		if($(".game-order-details").eq(2).length)
			$(".game-order-details").eq(2).html(
				$(".game-order-details").eq(0).html()
			)
		if($(".game-order-details").eq(3).length)
			$(".game-order-details").eq(3).html(
				$(".game-order-details").eq(0).html()
			)
	});
	
	
	function resizeF() {
		if($("#menubutton").is(":visible")) {
			if (lastMenuStatus == false) {
				
				$("#menu-area").hide();
				$("#menu-area").removeClass("visible");
				$("body").removeClass("noscroll");
			}
			
		}
		else {
			$("#menu-area").show();
			$("#menu-area").addClass("visible");
			$("body").addClass("noscroll");
		}
		
		$(".big-services .service").css("height","auto").equalHeights();
	}
	
	function scrollF() {
		
		$scroll = $(document).scrollTop();
		if($scroll >= 60)
			$("#header").addClass("scrolled");
		else
			$("#header").removeClass("scrolled");
	}
	
	$(window).on('resize', function(){
		resizeF();
		scrollF();
	});
	
	$(window).on('scroll', function(){
		scrollF();
	});
	
	$(function() {
		resizeF();
		scrollF();
	});
	
})(jQuery);