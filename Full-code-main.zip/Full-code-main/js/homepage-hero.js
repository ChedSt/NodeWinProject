
$(function() {
	
	var timeVisible = 15000;
	var timeVisibleLong = 25000;
	var timeTransition = 500;
	var timeQuickTransition = 300;
	
	
	var herodots = $("<div><div class='body'></div></div>").attr("id", 'hero-dots').appendTo("#hero-area");
	
	for(i=0;i< $("#hero-area .hero").length;i++)
		herodots.find(".body").append("<a>");
	
	
	var current = 0;
	var count = parseInt($("#hero-area .hero").length);
	var canclick = true;
	var canclickTimeout;
	
	// first dot is selected by default
	$("#hero-dots a").eq(0).addClass("selected");
	
	// dot clicks
	$("#hero-dots a").each(function (i,e) {
		
		$(e).click(function(ev) {
			ev.preventDefault();
			
			showhero(i, 1);
			
		});
	});
	
	// hide all heros
	$("#hero-area .hero").each(function(i,e) {
		$(e).css("transform","translate("+(i*100)+"%,0)")
		.show();
	});
	
	// show first hero
	$("#hero-area .hero").eq(0)
			.css("z-index","51")
			.transition({
				x: '0%',
				easing: 'linear',
        duration: 0 });
	
	// show any specified hero
	function showhero(showid, waitmore) {
		
		if(canclick) {
			canclick = false;
			waitmore = (typeof waitmore === 'undefined') ? 0 : waitmore;
			current = parseInt(showid);
			
			
			$("#hero-dots a").removeClass("selected").eq(current).addClass("selected");
			
			
			$("#hero-area .hero").each(function(i,e) {
				$(e).transition({
					x: (((i-current) % count)*100) + '%',
					easing: 'linear',
					duration: waitmore === 0 ? timeTransition : timeQuickTransition,
					queue: false
				})
				//css("transform","translate("+((i+current)*100)+"%,0)")
				.show();
				
			});
			
			clearTimeout(timeout);
			timeout = setTimeout(function () {
				displayNextHero();
			}, waitmore === 0 ? timeVisible : timeVisibleLong);
			
			canclickTimeout = setTimeout(function () {
				canclick = true;
			}, waitmore === 0 ? timeTransition : timeQuickTransition);
		}
	}
	
	function displayNextHero() {
		showhero((current + 1) % count);
	}
	
	var timeout = setTimeout(function() {displayNextHero();}, timeVisible);
	
	$("#hero-area, #hero-area .hero").css("height","auto").equalHeights();
	
});


